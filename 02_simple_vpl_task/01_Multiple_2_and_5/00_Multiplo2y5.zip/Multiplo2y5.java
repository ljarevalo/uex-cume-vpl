import java.io.*;
public class Multiplo2y5 {

    public static void main(String[] args) throws Exception{

		InputStreamReader reader=new InputStreamReader(System.in); 
	     BufferedReader Input=new BufferedReader (reader); 
	 	int numero = Integer.parseInt(Input.readLine()); 
        if (numero %2 ==0 && numero%5 ==0) {
			System.out.println("Si");
        }else {
        	System.out.println("No");
        }
    }

}
