import java.io.*;
public class Menorde3 {
    public static void main (String[] args)  throws IOException{    
        	InputStreamReader reader=
		new InputStreamReader(System.in); 
        	BufferedReader Input=new BufferedReader (reader); 
 	int valor1 = Integer.parseInt(Input.readLine()); 
	int valor2 = Integer.parseInt(Input.readLine()); 
	int valor3 = Integer.parseInt(Input.readLine()); 
	if (valor1<valor2){
	        if (valor1<valor3){  
		System.out.println(valor1);
	        }else { System.out.println(valor3);  }
	} else if (valor2<valor3){   
		System.out.println(valor2);
	} else {System.out.println(valor3);   }
     }
}
