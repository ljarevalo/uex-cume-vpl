import java.io.*;
public class Array {
    BufferedReader reader = new BufferedReader(
	new InputStreamReader(System.in));
    int []a=new int[10];
    public static void main( String args[] ) throws IOException {
        Array a=new Array();
        a.introducirDatos();
        System.out.print("Suma: "+a.suma());
        System.out.print(" Media: "+a.media());
        int valor=a.introducirValor();
        System.out.print(" Primera:"+a.primeraPosicion(valor));
        System.out.print(" Ocurrencias: "+a.numeroOcurrencias(valor));
        System.out.print(" Alto: "+a.masAlto());
    }    
    public void introducirDatos() throws IOException {
        for (int i=0;i<a.length;i++){
            a[i] = Integer.parseInt(reader.readLine( ));
        }
    }
    public int introducirValor() throws IOException{
        return Integer.parseInt(reader.readLine( ));
    }
    public int suma(){
        int suma=0;
        for(int i=0; i<a.length; i++) {
            suma=suma+a[i];
        }
        return suma;
    }
    
    public float media() {
        float media=0;
        media=Float.valueOf(suma())/a.length;
        return media;
    }
    public int primeraPosicion(int valor) throws IOException {
        int posicion=-1, i=0;
        boolean encontrado=false;
        while(!encontrado && i<a.length) {
            if(a[i]==valor){
                posicion=i;
                encontrado=true;
            }
            i++;
        }
        return posicion;
    }
    public int numeroOcurrencias (int valor) throws IOException {
        int numveces=0;
        for(int i=0; i<a.length; i++) {
            if(a[i]==valor){ numveces++;}
        }
        return numveces;
    }
    public int masAlto(){
        int  masalto=0;
        for(int i=0; i<a.length; i++){
            if(a[i]>masalto){masalto=a[i];}
        }
        return masalto;
    }
}
