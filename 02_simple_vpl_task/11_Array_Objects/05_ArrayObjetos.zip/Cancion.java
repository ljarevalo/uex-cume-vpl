public class Cancion {
	private String titulo;
	private String autor;
	private int tiempo;

	public Cancion() {
		titulo="";
		autor="";
		tiempo=0;
	}
	public Cancion(String ti, String a, int tie) {
		titulo=ti;
		autor=a;
		tiempo=tie;
	}
	public void setTitulo(String ti) {
		titulo = ti;
	}
	public void setAutor(String a) {
		autor = a;
	}
	public void setTiempo(String tie) {

	}
	public String getTitulo() {
		return titulo;
	}
	public String getAutor() {
		return autor;
	}
	public int getTiempo() {
		return tiempo;
	}
	public String toString() {
		return "["+titulo+","+autor+","+tiempo+"]";
	}
	public boolean equals(Cancion c) {
		return (titulo.equals(c.titulo)&& autor.equals(c.autor) && tiempo==c.tiempo);
	}
}
