
import java.util.Scanner;

public class Main {
    Cancion [] can;
	public static void main(String [] args) {
	    Main m = new Main();
		Scanner in = new Scanner(System.in);
		try {
			int num = in.nextInt();
			m.can= new Cancion[num];
			//------INICIALIZAR EL VECTOR------//
			for(int i=0;i<m.can.length;i++) {
				String titulo = in.next();
				String autor = in.next();
			    int tiempo = in.nextInt();			
				m.can[i] = new Cancion(titulo, autor, tiempo);
			}
			//------MOSTRAR VECTOR-----//
			for(int i=0;i<m.can.length;i++) {
				System.out.println(m.can[i].toString());
			}
			//------MEDIA Y SUMA------//
			float suma = 0;
			for(int i=0;i<m.can.length;i++) {
				suma=suma+m.can[i].getTiempo();
			}
			float media = suma/m.can.length;
			int alto = 0;
			for(int i=0;i<m.can.length;i++) {
			    if(m.can[i].getTiempo()>alto){
			        alto=m.can[i].getTiempo();
			    }
			}
			System.out.println("Media: "+media+" Alto: "+alto);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}