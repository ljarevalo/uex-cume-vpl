#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
    // Variables a utilizar
    long int Resultado=0;
    long int Factorial;

    // Solicitar numero para calcular el factorial
    scanf(" %ld", &Factorial);
    if (Factorial<0) else printf("error");
    else {
        
        // Calcular el factorial del numero solicitado
        Resultado = 1;
        while(Factorial > 1) {
            Resultado *= Factorial;
            Factorial--;
        }
        printf(Resultado);
    }
    return 0;
}
