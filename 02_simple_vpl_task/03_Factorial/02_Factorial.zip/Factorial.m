n = input('');
if n < 0
   fprintf('Error')
else
    f=1;
    for i = 1 : n
        f = f * i;
    end
    fprintf('%d',f)
end
