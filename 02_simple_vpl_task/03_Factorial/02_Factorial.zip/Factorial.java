
import java.io.*;   

public class Factorial{
    public static void main(String Arg[ ]) throws IOException{
    	long numero;
	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
     	numero = Integer.parseInt(in.readLine( ));
     	if (numero<0) System.out.println("error");
      	else System.out.println(factorial(numero));
      }    
     // declaración recursiva del método factorial
     static long factorial( long numero )	{
	if ( numero <= 1 ) return 1;			// caso base
	else return numero * factorial( numero - 1 );  	// paso recursivo
     } // fin del método factorial
} // fin de la clase PruebaFactorial
