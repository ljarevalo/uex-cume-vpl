n = input("");
if n<0
    disp("error")
else 
    if mod(n,2)==0 
        disp("Par")
    else
        disp("Impar")
    endif
endif

