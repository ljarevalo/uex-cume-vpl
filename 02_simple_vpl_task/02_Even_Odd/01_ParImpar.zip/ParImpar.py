n = int(input())
if n>=0:
    if n%2==0: print("Par")
    else: print("Impar")
else: print("error")
