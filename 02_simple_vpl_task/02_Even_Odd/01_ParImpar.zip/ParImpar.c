#include <stdio.h>

int main(void) {
  int numero;
  scanf("%d", &numero);
  if (numero<0) {
      printf("error");
  } else if (numero % 2 == 0) {
    printf("Par");
  } else {
    printf("Impar");
  }
  return 0;
}
