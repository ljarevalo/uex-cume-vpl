import java.io.*;
public class ParImpar {

    public static void main (String[] args)  throws IOException    {    

        InputStreamReader reader=new InputStreamReader(System.in); 
        BufferedReader Input=new BufferedReader (reader); 
        String name= Input.readLine(); 
        int valor1=Integer.parseInt(name);
        if (valor1<0) System.out.println("error");
        else if (valor1 %2 ==0){
            System.out.println("Par");
        }else{
            System.out.println("Impar");
        }
    }
}
